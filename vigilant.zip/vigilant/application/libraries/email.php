<?php
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = 'ssl://smtp.googlemail.com'; //change this
    //$config['smtp_host'] = '192.168.0.12'; //change this
    
    $config['smtp_port'] = '465';
    $config['smtp_user'] = ''; //change this
    $config['smtp_pass'] = ''; //change this
    $config['mailtype'] = 'html';
    $config['charset'] = 'iso-8859-1';
    $config['wordwrap'] = TRUE;
    $config['newline'] = "\r\n"; //use double quotes to comply with RFC 822 standard
?>